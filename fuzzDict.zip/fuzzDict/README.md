## content
* [apiDict]——api接口字典
* [ctfDict]——ctf字典
* [directoryDicts]——目录字典(asp\aspx\jsp\php)
* [easyXssPayload]——XSS字典
* [js]——js文件字典
* [routerDicts]——路由器后台字典和密码
* [sqlDict]——sql-fuzz字典
* [ssrf-fuzz字典]——ssrf-fuzz字典
* [subdomainDicts]——子域名爆破字典
* [uploadFileExtDicts]——文件上传漏洞fuzz字典
* [Web_Middleware_other]——web中间件字典
* [Web_shell]——Web_shell爆破字典
* [XXE字典]——XXE字典
* [密码字典]——密码字典
* [名字字典]——用户名字典
* [目录]——目录字典(asp\aspx\jsp\php)


